<link rel="stylesheet" href="admin.css">
<footer>
		<p>&copy; 2023 Tours and Travels</p>
	</footer>
</body>
</html>
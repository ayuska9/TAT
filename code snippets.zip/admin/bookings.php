<!DOCTYPE html>
<html>
<head>
    <title>Booking List</title>
    <link rel="stylesheet" type="text/css" href="booking.css">
</head>
<body>
<header>
	<h1>Tours and Travels</h1>
    <nav>
			<ul>
                <li><a href="admin.php">Dashboard</a></li>
                <li><a href="bookings.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'bookings.php' ? 'active' : ''; ?>">Bookings</a></li>
                <li><a href="../inquiry/view_inquiry.php">Issues</a></li>
                <li><a href="user.php">Users</a></li>
                <li><a href="../image/index.php">Packages</a></li>
			    <li><a href="../index.php">Login</a></li>	
			</ul>
		</nav>
</header>

    <div class="content">
        <h1>Booking List</h1>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>User ID</th>
                    <th>Package ID</th>
                    <th>Status</th>
                    <th>Schedule</th>
                    <th>Date Created</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
            <?php
    // Connect to database
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "tat";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Check if delete button was clicked and delete booking if confirmed
    if (isset($_GET['delete_id']) && !empty($_GET['delete_id'])) {
        $delete_id = $_GET['delete_id'];
        $sql = "DELETE FROM book_list WHERE Id = $delete_id";
        if ($conn->query($sql) === TRUE) {
            echo "Booking deleted successfully";
        } else {
            echo "Error deleting booking: " . $conn->error;
        }
    }

    // Query to retrieve bookings
    $sql = "SELECT Id, user_id, package_id, status, schedule, date_created FROM book_list";
    $result = $conn->query($sql);

    if ($result !== false && $result->num_rows > 0) {
        // Output data of each row
        while($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row["Id"] . "</td>";
            echo "<td>" . $row["user_id"] . "</td>";
            echo "<td>" . $row["package_id"] . "</td>";
            echo "<td>" . $row["status"] . "</td>";
            echo "<td>" . $row["schedule"] . "</td>";
            echo "<td>" . $row["date_created"] . "</td>";
            echo "<td>";
            echo "<button class=\"edit\" onclick=\"window.location.href='edit_booking.php?edit_id=".$row["Id"]."';\">Edit</button>";
            echo "<button class=\"delete\" onclick=\"if(confirm('Are you sure you want to delete this booking?')){ window.location.href='booking.php?delete_id=".$row["Id"]."'; }\">Delete</button>";
            echo "</td>";
            echo "</tr>";
        }
    }

    // Close database connection
    $conn->close();
?>

            </tbody>
        </table>
    </div>
</body>
</html>

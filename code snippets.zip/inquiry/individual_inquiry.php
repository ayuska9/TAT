<?php
include('../admin/header.php');
?>
<?php

// Establish a database connection
$host = "localhost";
$username = "root";
$password = "";
$dbname = "tat";

$conn = mysqli_connect($host, $username, $password, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Retrieve inquiry data based on the provided id
$id = mysqli_real_escape_string($conn, $_GET['id']);
$sql = "SELECT * FROM inquiry WHERE inquiry_id = '$id'";
$result = mysqli_query($conn, $sql);

// Display inquiry data
if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    ?>
    <div class="container mt-4">
        <h2 class="mb-3"><?php echo $row['subject']; ?></h2>
        <div class="card">
            <div class="card-body">
                <p><strong>Name:</strong> <?php echo $row['name']; ?></p>
                <p><strong>Email:</strong> <?php echo $row['email']; ?></p>
                <p><strong>Description:</strong></p>
                <p><?php echo $row['description']; ?></p>
            </div>
        </div>
    </div></div>
    <?php
} else {
    echo "Inquiry not found.";
}

mysqli_close($conn);

?>
<!-- Include Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<?php
include('../admin/footer.php');
?>
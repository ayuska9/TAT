<?php 
session_start();
?>
<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.rtl.min.css"
        integrity="sha384-T5m5WERuXcjgzF8DAb7tRkByEZQGcpraRTinjpywg37AO96WoYN9+hrhDVoM6CaT" crossorigin="anonymous">

    <title>Edit package</title>
</head>

<body>
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Edit package</h4>
                    </div>
                    <div class="card-body">
                        <?php 
                        $conn = mysqli_connect("localhost","root","","tat");
                        $id = $_GET['package_id'];
                        $query = "SELECT * FROM packages WHERE package_id ='$id'";
                        $query_run = mysqli_query($conn, $query);

                        if(mysqli_num_rows($query_run)>0){
                            foreach($query_run as $row){
                                
                                ?>
<form action="code.php" method="POST" enctype="multipart/form-data">
    <input type="hidden" value="<?php echo $row['package_id'];  ?>"/>
                            <div class="form-group">
                                <label for="">Tour name</label>
                                <input type="text" name="tour_name" value="<?php echo $row['title'];  ?>" required class="form-control"
                                    placeholder="Tour name">
                            </div>
                            <div class="form-group">
                                <label for="">Tour Location</label>
                                <input type="text" required name="tour_location" value="<?php echo $row['tour_location'];  ?>" class="form-control"
                                    placeholder="Tour location">
                            </div>
                            <div class="form-group">
                                <label for="">Tour Cost</label>
                                <input type="number" required name="cost" value="<?php echo $row['cost'];  ?>"  class="form-control" placeholder="Cost">
                            </div>
                            <div class="form-group">
                                <label for="">Description</label>
                                <input type="text" required name="description" class="form-control" value="<?php echo $row['description'];  ?>"
                                    placeholder="Description">
                            </div>
                            <div class="form-group">
                                <label for="">Image</label>
                                <input type="file" name="image" accept="image/*" class="form-control" placeholder="Image">
                                <input type="hidden" name="old_image" value="<?php echo $row['image'];  ?>" >
                            </div>
                            <img src="<?php echo "package/".$row['image'];?>" width="100px">

                            <div class="form-group">
                                <label for="">Tour status</label>
                                <select name="tour_status" class="form-control">
                                <?php
                                    if ($row['status'] == 1) {
                                    echo '<option value="active" selected>Active</option>';
                                    echo '<option value="inactive">Inactive</option>';
                                    } else {
                                    echo '<option value="active">Active</option>';
                                    echo '<option value="inactive" selected>Inactive</option>';
                                    }
                                ?>
                                </select>&nbsp;
                            </div>

                            <div class="form-group">
                                <button type="submit" name="update_package" class="btn btn-primary">UPDATE</button>
                            </div>
                                <?php

                            }
                        }else{
                            echo "No package.";
                        }
                        ?>    


                        


                    </div>
                </div>
            </div>
        </div>
    </div>


    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.min.js"></script>

</body>

</html>
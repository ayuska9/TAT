<link rel="stylesheet" href="../style.css">
<link rel="stylesheet" href="style.css">
<header>
    <h1>Tours and Travels</h1>
    <nav>
        <ul>
            <li><a href="../#about">About Us</a></li>
            <li><a href="package_view.php">Tours</a></li>
            <li><a href="../#contact">Contact Us</a></li>
            <?php
            session_start();
            if (isset($_SESSION['username'])) {
                $username = $_SESSION['username'];
                echo "<li><a>Welcome, $username</a></li>";
                echo '<li><a href="logout.php">Logout</a></li>';
            } else {
                echo '<li><a href="login.php">Login</a></li>';
                echo '<li><a href="signup.php">Signup</a></li>';
            }
            ?>
        </ul>
    </nav>
</header>


<?php
// Establish a database connection
$host = "localhost";
$username = "root";
$password = "";
$dbname = "tat";
$conn = mysqli_connect($host, $username, $password, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Retrieve package data
$sql = "SELECT * FROM packages";
$result = mysqli_query($conn, $sql);
?>

<div class="container">
    <div class="row">
        <?php
        // Loop through package data and display in cards
        while ($row = mysqli_fetch_assoc($result)) {
        ?>
            <div class="col-md-4">
                <div class="card">
                <img src="<?php echo "package/".$row['image']; ?>" width="400px" alt="<?php echo $row['title']; ?>">

                    <div class="card-body">
                        <h5 class="card-title"><?php echo $row['title']; ?></h5>
                        <p class="card-text"><?php echo $row['description']; ?></p>
                        <p class="card-text"><strong>Price: $</strong> <?php echo $row['cost']; ?></p>
                        <a href="#" class="btn btn-primary">Book Now</a>
                    </div>
                </div>
            </div>
        <?php
        }
        mysqli_close($conn);
        ?>
    </div>
</div>
<?php include('../footer.php') ?>

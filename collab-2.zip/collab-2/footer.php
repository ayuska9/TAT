<footer>
		<p>&copy; 2023 Tours and Travels</p>
	</footer>